int determine_winner(int played_cards[4], int starter, char hokm);

int decide_what_to_play(
    int player,
    int self_cards[4][11],
    int starter,
    int played_cards[4],
    char hokm
);