void draw(
    int players_cards[4][4][11],
    char hokm,
    int round,
    char msg[],
    int points[2],
    int played_cards[4],
    int sets[2]
);